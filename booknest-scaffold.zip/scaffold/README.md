# BookNest — Full-stack Starter Scaffold

## Structure
- `backend/` — Express API + Prisma (Postgres). Models in `prisma/schema.prisma`, routes in `src/routes/`.
- `frontend/` — Vite + React + Tailwind. Pages in `src/pages/`, API client in `src/lib/api.js`.

## Running locally (needs internet access for installs)
```bash
# backend
cd backend
cp .env.example .env   # fill in a real Postgres URL and secrets
npm install
npx prisma migrate dev --name init
npm run dev             # http://localhost:4000

# frontend (new terminal)
cd frontend
npm install
npm run dev              # http://localhost:5173
```

## What's stubbed vs real
- Auth: real signup/login/refresh/2FA logic against Postgres. Email verification and Google OAuth are wired as TODOs — add `passport-google-oauth20` strategy and a mail sender (e.g. Resend/SendGrid).
- Library, Clubs, Marketplace: real CRUD routes and matching React Query pages.
- Reading Rooms: Socket.IO namespace per room broadcasts live progress between connected readers ("Read Together").
- Notifications, global search, admin dashboard: modeled in `ARCHITECTURE.md` but not scaffolded yet — next in the phased plan.

See `../ARCHITECTURE.md` for the full data model, API surface, and delivery phasing.
