import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

router.get('/', async (_req, res) => {
  const clubs = await prisma.club.findMany({
    where: { isPrivate: false },
    include: { _count: { select: { members: true } } },
  });
  res.json(clubs);
});

router.post('/', async (req, res) => {
  const club = await prisma.club.create({
    data: {
      name: req.body.name,
      description: req.body.description,
      isPrivate: !!req.body.isPrivate,
      ownerId: req.user.sub,
      members: { create: { userId: req.user.sub, role: 'OWNER' } },
    },
  });
  res.status(201).json(club);
});

router.get('/:id', async (req, res) => {
  const club = await prisma.club.findUnique({
    where: { id: req.params.id },
    include: { members: { include: { user: true } }, polls: true },
  });
  if (!club) return res.status(404).json({ error: 'Club not found' });
  res.json(club);
});

router.post('/:id/join', async (req, res) => {
  const membership = await prisma.clubMember.create({
    data: { clubId: req.params.id, userId: req.user.sub, role: 'MEMBER' },
  });
  res.status(201).json(membership);
});

router.post('/:id/polls', async (req, res) => {
  const poll = await prisma.clubPoll.create({
    data: {
      clubId: req.params.id,
      question: req.body.question,
      options: req.body.options,
      closesAt: new Date(req.body.closesAt),
    },
  });
  res.status(201).json(poll);
});

export default router;
