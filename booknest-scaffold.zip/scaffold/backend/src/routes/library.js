import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

// GET /library?status=READING
router.get('/', async (req, res) => {
  const { status } = req.query;
  const entries = await prisma.userBook.findMany({
    where: { userId: req.user.sub, ...(status ? { status } : {}) },
    include: { book: true },
    orderBy: { finishedAt: 'desc' },
  });
  res.json(entries);
});

// POST /library/:bookId  { status }
router.post('/:bookId', async (req, res) => {
  const entry = await prisma.userBook.upsert({
    where: { userId_bookId: { userId: req.user.sub, bookId: req.params.bookId } },
    update: { status: req.body.status },
    create: { userId: req.user.sub, bookId: req.params.bookId, status: req.body.status },
  });
  res.status(201).json(entry);
});

// PATCH /library/:bookId  { progressPage, rating, review, status }
router.patch('/:bookId', async (req, res) => {
  const { progressPage, rating, review, status } = req.body;
  const entry = await prisma.userBook.update({
    where: { userId_bookId: { userId: req.user.sub, bookId: req.params.bookId } },
    data: {
      ...(progressPage !== undefined && { progressPage }),
      ...(rating !== undefined && { rating }),
      ...(review !== undefined && { review }),
      ...(status !== undefined && { status, ...(status === 'COMPLETED' && { finishedAt: new Date() }) }),
    },
  });
  res.json(entry);
});

// GET /library/analytics — genres, pace, milestones
router.get('/analytics/summary', async (req, res) => {
  const completed = await prisma.userBook.findMany({
    where: { userId: req.user.sub, status: 'COMPLETED' },
    include: { book: true },
  });

  const totalPages = completed.reduce((sum, e) => sum + (e.book.pageCount || 0), 0);
  const genreCounts = completed.flatMap((e) => e.book.genres).reduce((acc, g) => {
    acc[g] = (acc[g] || 0) + 1;
    return acc;
  }, {});

  res.json({
    booksCompleted: completed.length,
    totalPages,
    favoriteGenres: Object.entries(genreCounts).sort((a, b) => b[1] - a[1]).slice(0, 5),
  });
});

export default router;
