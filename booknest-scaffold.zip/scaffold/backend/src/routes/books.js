import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

// GET /books?query=&genre=&sort=
router.get('/', async (req, res) => {
  const { query, genre, sort = 'title' } = req.query;

  const books = await prisma.book.findMany({
    where: {
      AND: [
        query ? { OR: [{ title: { contains: query, mode: 'insensitive' } }, { author: { contains: query, mode: 'insensitive' } }] } : {},
        genre ? { genres: { has: genre } } : {},
      ],
    },
    orderBy: { [sort]: 'asc' },
    take: 50,
  });

  res.json(books);
});

router.get('/:id', async (req, res) => {
  const book = await prisma.book.findUnique({
    where: { id: req.params.id },
    include: { listings: { where: { status: 'AVAILABLE' } } },
  });
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.json(book);
});

export default router;
