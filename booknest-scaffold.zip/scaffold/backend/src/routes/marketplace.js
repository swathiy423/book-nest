import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

// GET /marketplace/listings?genre=&condition=
router.get('/listings', async (req, res) => {
  const { genre, condition } = req.query;
  const listings = await prisma.listing.findMany({
    where: {
      status: 'AVAILABLE',
      ...(genre ? { preferredGenres: { has: genre } } : {}),
      ...(condition ? { condition } : {}),
    },
    include: { book: true, owner: { select: { id: true, name: true, avatarUrl: true, trustScore: true } } },
  });
  res.json(listings);
});

router.post('/listings', async (req, res) => {
  const { bookId, condition, photos, preferredGenres } = req.body;
  const listing = await prisma.listing.create({
    data: { ownerId: req.user.sub, bookId, condition, photos, preferredGenres },
  });
  res.status(201).json(listing);
});

router.post('/listings/:id/request', async (req, res) => {
  const request = await prisma.exchangeRequest.create({
    data: { listingId: req.params.id, requesterId: req.user.sub },
  });

  await prisma.listing.update({ where: { id: req.params.id }, data: { status: 'PENDING' } });

  // TODO: emit notification + real-time message thread creation
  res.status(201).json(request);
});

export default router;
