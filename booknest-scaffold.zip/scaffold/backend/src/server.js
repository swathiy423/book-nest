import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { createServer } from 'http';
import { Server as SocketServer } from 'socket.io';

import authRoutes from './routes/auth.js';
import libraryRoutes from './routes/library.js';
import bookRoutes from './routes/books.js';
import clubRoutes from './routes/clubs.js';
import marketplaceRoutes from './routes/marketplace.js';
import { requireAuth } from './middleware/auth.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173', credentials: true }));
app.use(express.json());
app.use(cookieParser());

app.use('/auth', authRoutes);
app.use('/books', bookRoutes);
app.use('/library', requireAuth, libraryRoutes);
app.use('/clubs', requireAuth, clubRoutes);
app.use('/marketplace', requireAuth, marketplaceRoutes);

app.get('/health', (_req, res) => res.json({ ok: true }));

const httpServer = createServer(app);
const io = new SocketServer(httpServer, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:5173', credentials: true },
});

// Reading-room presence: users joining a room see each other's live progress.
io.of(/^\/rooms\/.+/).on('connection', (socket) => {
  const room = socket.nsp.name;
  socket.on('progress', (data) => socket.nsp.emit('presence', { socketId: socket.id, ...data }));
  socket.on('disconnect', () => socket.nsp.emit('left', { socketId: socket.id }));
});

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => console.log(`BookNest API listening on :${PORT}`));
