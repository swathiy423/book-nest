import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import Landing from './pages/Landing.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Library from './pages/Library.jsx';
import ReadingRoom from './pages/ReadingRoom.jsx';
import Clubs from './pages/Clubs.jsx';
import Marketplace from './pages/Marketplace.jsx';
import './index.css';

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/app" element={<Dashboard />} />
          <Route path="/app/library" element={<Library />} />
          <Route path="/app/rooms/:roomId" element={<ReadingRoom />} />
          <Route path="/app/clubs" element={<Clubs />} />
          <Route path="/app/marketplace" element={<Marketplace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);
