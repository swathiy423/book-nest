import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';

export default function Marketplace() {
  const { data: listings = [] } = useQuery({
    queryKey: ['listings'],
    queryFn: () => api.get('/marketplace/listings'),
  });

  return (
    <main className="min-h-screen bg-ink text-paper font-body p-8">
      <h1 className="font-display text-3xl mb-6">Exchange Marketplace</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        {listings.map((l) => (
          <div key={l.id} className="bg-surface rounded-xl p-4">
            <p className="font-display text-brass">{l.book.title}</p>
            <p className="text-xs text-muted">{l.condition}</p>
            <p className="text-xs text-clothblue mt-2">{l.owner.name} · trust {l.owner.trustScore}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
