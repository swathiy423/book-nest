import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';

export default function Dashboard() {
  const { data: summary } = useQuery({
    queryKey: ['analytics-summary'],
    queryFn: () => api.get('/library/analytics/summary'),
  });

  // Full visual design for this screen lives in prototypes/dashboard.html —
  // this component wires the same layout to live data once the API is running.
  return (
    <main className="min-h-screen bg-ink text-paper font-body p-8">
      <h1 className="font-display text-3xl mb-6">Welcome back</h1>
      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Books completed" value={summary?.booksCompleted ?? '—'} />
        <StatCard label="Total pages read" value={summary?.totalPages ?? '—'} />
        <StatCard label="Top genre" value={summary?.favoriteGenres?.[0]?.[0] ?? '—'} />
      </div>
    </main>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="bg-surface rounded-xl p-6">
      <p className="text-muted text-sm">{label}</p>
      <p className="font-display text-3xl text-brass">{value}</p>
    </div>
  );
}
