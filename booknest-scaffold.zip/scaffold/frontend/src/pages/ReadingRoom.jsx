import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';

// Full ambient/visual treatment lives in prototypes/reading-room.html.
// This is the connected version: joins the room's socket namespace and
// timer/progress state.
export default function ReadingRoom() {
  const { roomId } = useParams();
  const [peers, setPeers] = useState({});
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const socketRef = useRef(null);

  useEffect(() => {
    const socket = io(`${import.meta.env.VITE_API_URL || 'http://localhost:4000'}/rooms/${roomId}`, {
      withCredentials: true,
    });
    socketRef.current = socket;
    socket.on('presence', (data) => setPeers((p) => ({ ...p, [data.socketId]: data })));
    socket.on('left', (data) => setPeers((p) => { const next = { ...p }; delete next[data.socketId]; return next; }));
    return () => socket.disconnect();
  }, [roomId]);

  useEffect(() => {
    const t = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <main className="min-h-screen bg-ink text-paper font-body p-8">
      <h1 className="font-display text-2xl mb-2">Room: {roomId}</h1>
      <p className="font-mono text-brass text-4xl mb-6">
        {String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:{String(secondsLeft % 60).padStart(2, '0')}
      </p>
      <p className="text-muted text-sm">{Object.keys(peers).length} others reading here now</p>
    </main>
  );
}
