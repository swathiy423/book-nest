import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';

export default function Clubs() {
  const { data: clubs = [] } = useQuery({ queryKey: ['clubs'], queryFn: () => api.get('/clubs') });

  return (
    <main className="min-h-screen bg-ink text-paper font-body p-8">
      <h1 className="font-display text-3xl mb-6">Book Clubs</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {clubs.map((club) => (
          <div key={club.id} className="bg-surface rounded-xl p-5">
            <h2 className="font-display text-lg text-brass">{club.name}</h2>
            <p className="text-sm text-muted mt-1">{club.description}</p>
            <p className="text-xs text-clothblue mt-3">{club._count?.members ?? 0} members</p>
          </div>
        ))}
      </div>
    </main>
  );
}
