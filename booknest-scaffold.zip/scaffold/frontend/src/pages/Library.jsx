import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';

const SHELVES = ['READING', 'WANT', 'COMPLETED', 'FAVORITE', 'WISHLIST', 'DROPPED'];

export default function Library() {
  const { data: entries = [], isLoading } = useQuery({
    queryKey: ['library'],
    queryFn: () => api.get('/library'),
  });

  return (
    <main className="min-h-screen bg-ink text-paper font-body p-8">
      <h1 className="font-display text-3xl mb-6">Your Library</h1>
      {isLoading && <p className="text-muted">Loading shelves…</p>}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {SHELVES.map((shelf) => (
          <section key={shelf} className="bg-surface rounded-xl p-4">
            <h2 className="font-display text-lg text-brass mb-3">{shelf.replace('_', ' ')}</h2>
            <ul className="space-y-2">
              {entries.filter((e) => e.status === shelf).map((e) => (
                <li key={e.id} className="text-sm">
                  {e.book.title} — <span className="text-muted">{e.book.author}</span>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </main>
  );
}
