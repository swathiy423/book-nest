import { Link } from 'react-router-dom';

// Full marketing design lives in prototypes/landing.html — this stub is the
// routable placeholder until that markup is ported into components.
export default function Landing() {
  return (
    <main className="min-h-screen bg-ink text-paper font-body flex flex-col items-center justify-center gap-6">
      <h1 className="font-display text-5xl text-brass">BookNest</h1>
      <p className="text-muted max-w-md text-center">A reading community, a digital library, and a book exchange — one nest for every book you'll ever read.</p>
      <Link to="/app" className="bg-brass text-ink px-6 py-3 rounded-full font-body font-semibold">Enter the nest</Link>
    </main>
  );
}
